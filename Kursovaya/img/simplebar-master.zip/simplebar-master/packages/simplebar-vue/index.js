import simplebar from './index.vue';

export default simplebar;
